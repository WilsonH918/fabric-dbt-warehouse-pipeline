{{ config(materialized='view') }}

select
  cast(AccountID as varchar(100)) as account_id,
  *
from {{ source('lakehouse', 'accounts') }}