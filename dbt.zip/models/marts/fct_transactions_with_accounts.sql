{{ config(materialized='table') }}

with tx as (
    select *
    from {{ ref('stg_transactions') }}
),
ac as (
    select *
    from {{ ref('stg_accounts') }}
)

select
    tx.AccountID,
    tx.TransactionID,
    tx.TransactionDate,
    tx.Amount,
    ac.AccountType,
    ac.Balance
from tx
left join ac on tx.AccountID = ac.AccountID;